<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Mail\Message;
use Illuminate\Support\Facades\Password;

use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
class adminresetController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    use SendsPasswordResetEmails;
    //protected $broker = 'admins';
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
     
        $this->middleware('guest:admin');
     
    }
    public function broker()
	{
    return Password::broker('admins');
	}
    public function sendEmail(Request $request) {
        try {
            $email_address = $request->email;
            $credentials = ['email' => $email_address];
            $response = Password::sendResetLink($credentials, function (Message $message) {
                        $message->subject($this->getEmailSubject());
                    });
            switch ($response) {
                case Password::RESET_LINK_SENT:
                    return response()->json(['code' => '200', 'message' => trans($response)]);
                    break;
                case Password::INVALID_USER:
                    return response()->json(['code' => '201', 'message' => trans($response)]);
                    break;
            }
        } catch (Exception $ex) {
            return response()->json(['code' => '999', 'message' => $this->getSiteconfigValueByKey('UNAUTHORISED')]);
        }
    }
}
